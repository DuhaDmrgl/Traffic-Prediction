# Traffic-Prediction
 Hourly traffic data on four different junctions
